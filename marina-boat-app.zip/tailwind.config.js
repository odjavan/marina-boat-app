/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'marina-blue': '#0066CC',
        'marina-dark': '#003d99',
        'marina-light': '#e6f0ff',
      },
    },
  },
  plugins: [],
}
