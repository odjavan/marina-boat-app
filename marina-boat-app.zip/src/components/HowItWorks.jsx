import { ChevronDown } from 'lucide-react'
import { useState } from 'react'

function HowItWorks({ title, description, steps }) {
  const [expanded, setExpanded] = useState(false)

  return (
    <div className="card bg-marina-light border-2 border-marina-blue mb-8">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between"
      >
        <div className="text-left">
          <h3 className="font-bold text-marina-blue text-lg flex items-center gap-2">
            ❓ {title}
          </h3>
          <p className="text-sm text-gray-700 mt-1">{description}</p>
        </div>
        <ChevronDown
          size={24}
          className={`text-marina-blue transition-transform ${expanded ? 'rotate-180' : ''}`}
        />
      </button>

      {expanded && (
        <div className="mt-6 pt-6 border-t border-marina-blue">
          <div className="space-y-4">
            {steps.map((step) => (
              <div key={step.number} className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-8 w-8 rounded-full bg-marina-blue text-white font-bold text-sm">
                    {step.number}
                  </div>
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-800">{step.title}</h4>
                  <p className="text-sm text-gray-700 mt-1">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export default HowItWorks

