import { useNavigate, useLocation } from 'react-router-dom'
import { Home, Wrench, Ship, Bell, User } from 'lucide-react'

function Navigation() {
  const navigate = useNavigate()
  const location = useLocation()

  const isActive = (path) => location.pathname === path

  const navItems = [
    { path: '/', label: 'Home', icon: Home },
    { path: '/services', label: 'Serviços', icon: Wrench },
    { path: '/vessels', label: 'Embarcações', icon: Ship },
    { path: '/notifications', label: 'Notificações', icon: Bell },
    { path: '/profile', label: 'Perfil', icon: User },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
      <div className="flex justify-around items-center h-20 max-w-2xl mx-auto w-full">
        {navItems.map((item) => {
          const Icon = item.icon
          const active = isActive(item.path)
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center justify-center w-full h-full transition-colors ${
                active
                  ? 'text-marina-blue border-t-4 border-marina-blue'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon size={24} />
              <span className="text-xs mt-1 font-medium">{item.label}</span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}

export default Navigation

