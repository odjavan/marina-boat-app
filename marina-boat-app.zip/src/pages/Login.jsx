import { useState } from 'react'
import { Ship, Mail, Lock } from 'lucide-react'

function Login({ onLogin }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [isSignUp, setIsSignUp] = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    if (email && password) {
      onLogin({
        email,
        name: email.split('@')[0],
        avatar: 'https://via.placeholder.com/150',
      })
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-marina-blue to-marina-dark flex flex-col items-center justify-center p-4">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <Ship size={48} className="text-white" />
        </div>
        <h1 className="text-4xl font-bold text-white mb-2">Marina Boat</h1>
        <p className="text-marina-light text-lg">Gestão Completa de Serviços Náuticos</p>
      </div>

      {/* Form Card */}
      <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
          {isSignUp ? 'Criar Conta' : 'Entrar'}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-gray-700 font-semibold mb-2">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 text-gray-400" size={20} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                className="input-field pl-10"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-700 font-semibold mb-2">Senha</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 text-gray-400" size={20} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="input-field pl-10"
                required
              />
            </div>
          </div>

          <button type="submit" className="btn-primary w-full mt-6">
            {isSignUp ? 'Criar Conta' : 'Entrar'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-gray-600">
            {isSignUp ? 'Já tem conta?' : 'Não tem conta?'}{' '}
            <button
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-marina-blue font-semibold hover:underline"
            >
              {isSignUp ? 'Entrar' : 'Cadastre-se'}
            </button>
          </p>
        </div>

        {/* Demo Note */}
        <div className="mt-6 p-4 bg-marina-light rounded-lg border border-marina-blue">
          <p className="text-sm text-gray-700">
            <strong>Demo:</strong> Use qualquer email e senha para entrar. Este é um protótipo.
          </p>
        </div>
      </div>

      {/* Footer */}
      <p className="text-white text-sm mt-8 text-center">
        © 2025 Marina Boat. Todos os direitos reservados.
      </p>
    </div>
  )
}

export default Login

