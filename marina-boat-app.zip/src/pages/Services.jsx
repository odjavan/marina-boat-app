import { useState } from 'react'
import { Wrench, Plus, ChevronRight } from 'lucide-react'
import HowItWorks from '../components/HowItWorks'

function Services() {
  const [selectedCategory, setSelectedCategory] = useState(null)
  const [showForm, setShowForm] = useState(false)

  const serviceCategories = [
    {
      id: 1,
      name: 'Limpeza',
      icon: '🧹',
      services: [
        'Limpeza Simples (Externa)',
        'Limpeza Completa (Interna/Externa)',
        'Enceramento e Polimento',
        'Limpeza de Cascos (Fundo)',
      ],
    },
    {
      id: 2,
      name: 'Abastecimento',
      icon: '⛽',
      services: [
        'Combustível (Gasolina)',
        'Combustível (Diesel)',
        'Água Potável',
        'Gás de Cozinha',
      ],
    },
    {
      id: 3,
      name: 'Manutenção Preventiva',
      icon: '🔧',
      services: [
        'Revisão de Motores',
        'Troca de Óleo',
        'Verificação de Sistemas Elétricos',
        'Inspeção de Cascos',
      ],
    },
    {
      id: 4,
      name: 'Manutenção Corretiva',
      icon: '🔨',
      services: [
        'Reparos Elétricos',
        'Reparos Mecânicos',
        'Reparos Estruturais',
        'Pintura e Gelcoat',
      ],
    },
  ]

  return (
    <div className="max-w-2xl mx-auto p-4 pt-6 pb-24">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Serviços</h1>
        <p className="text-gray-600">Solicite serviços para suas embarcações</p>
      </div>

      {/* Service Categories */}
      <div className="space-y-3 mb-8">
        {serviceCategories.map((category) => (
          <div
            key={category.id}
            className="card cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => setSelectedCategory(selectedCategory === category.id ? null : category.id)}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{category.icon}</span>
                <div>
                  <h3 className="font-bold text-gray-800">{category.name}</h3>
                  <p className="text-sm text-gray-600">{category.services.length} opções</p>
                </div>
              </div>
              <ChevronRight
                size={24}
                className={`text-marina-blue transition-transform ${
                  selectedCategory === category.id ? 'rotate-90' : ''
                }`}
              />
            </div>

            {/* Expanded Services */}
            {selectedCategory === category.id && (
              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="space-y-2">
                  {category.services.map((service, idx) => (
                    <button
                      key={idx}
                      onClick={(e) => {
                        e.stopPropagation()
                        setShowForm(true)
                      }}
                      className="w-full text-left p-3 bg-marina-light rounded-lg hover:bg-marina-blue hover:text-white transition-colors text-sm font-medium"
                    >
                      {service}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Service Request Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end z-50">
          <div className="bg-white w-full rounded-t-3xl p-6 max-h-96 overflow-y-auto">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Solicitar Serviço</h2>

            <form className="space-y-4">
              <div>
                <label className="block text-gray-700 font-semibold mb-2">Embarcação</label>
                <select className="input-field">
                  <option>Lancha Azul</option>
                  <option>Veleiro Branco</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-700 font-semibold mb-2">Data Preferencial</label>
                <input type="date" className="input-field" />
              </div>

              <div>
                <label className="block text-gray-700 font-semibold mb-2">Urgência</label>
                <select className="input-field">
                  <option>Normal</option>
                  <option>Urgente</option>
                  <option>Emergencial</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-700 font-semibold mb-2">Observações</label>
                <textarea
                  className="input-field h-24 resize-none"
                  placeholder="Descreva o problema ou o que você precisa..."
                ></textarea>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="btn-secondary flex-1"
                >
                  Cancelar
                </button>
                <button type="submit" className="btn-primary flex-1">
                  Enviar Solicitação
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* How It Works */}
      <HowItWorks
        title="Como Solicitar um Serviço"
        description="Passo a passo para solicitar um serviço à sua marina"
        steps={[
          {
            number: 1,
            title: 'Escolha a Categoria',
            description: 'Selecione a categoria do serviço que você precisa (Limpeza, Abastecimento, Manutenção, etc.).',
          },
          {
            number: 2,
            title: 'Selecione o Serviço',
            description: 'Clique no serviço específico que deseja solicitar. A lista se expande mostrando todas as opções.',
          },
          {
            number: 3,
            title: 'Preencha o Formulário',
            description: 'Escolha a embarcação, data preferencial, urgência e adicione observações sobre o problema ou necessidade.',
          },
          {
            number: 4,
            title: 'Envie a Solicitação',
            description: 'Clique em "Enviar Solicitação". A marina receberá seu pedido e entrará em contato em breve com um orçamento.',
          },
        ]}
      />
    </div>
  )
}

export default Services

