import { AlertCircle, Calendar, Anchor, TrendingUp } from 'lucide-react'
import HowItWorks from '../components/HowItWorks'

function Home({ user }) {
  const upcomingServices = [
    {
      id: 1,
      type: 'Limpeza Completa',
      vessel: 'Lancha Azul',
      date: '2025-10-28',
      status: 'Agendado',
      color: 'bg-blue-100 border-blue-300',
    },
    {
      id: 2,
      type: 'Manutenção de Motor',
      vessel: 'Veleiro Branco',
      date: '2025-10-30',
      status: 'Em Andamento',
      color: 'bg-yellow-100 border-yellow-300',
    },
  ]

  const alerts = [
    {
      id: 1,
      type: 'Documento',
      message: 'Seguro do barco vence em 15 dias',
      icon: AlertCircle,
      color: 'text-red-500',
    },
    {
      id: 2,
      type: 'Manutenção',
      message: 'Revisão de motor agendada para próxima semana',
      icon: Anchor,
      color: 'text-blue-500',
    },
  ]

  return (
    <div className="max-w-2xl mx-auto p-4 pt-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Olá, {user?.name || 'Usuário'}! 👋
        </h1>
        <p className="text-gray-600">Bem-vindo ao Marina Boat</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Serviços Agendados</p>
              <p className="text-2xl font-bold text-marina-blue">2</p>
            </div>
            <Calendar className="text-marina-blue" size={32} />
          </div>
        </div>
        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Embarcações</p>
              <p className="text-2xl font-bold text-marina-blue">2</p>
            </div>
            <Anchor className="text-marina-blue" size={32} />
          </div>
        </div>
      </div>

      {/* Upcoming Services */}
      <div className="mb-8">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Próximos Serviços</h2>
        {upcomingServices.map((service) => (
          <div
            key={service.id}
            className={`card border-l-4 ${service.color} cursor-pointer hover:shadow-lg transition-shadow`}
          >
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-gray-800">{service.type}</h3>
                <p className="text-sm text-gray-600 mt-1">{service.vessel}</p>
                <p className="text-xs text-gray-500 mt-2">{service.date}</p>
              </div>
              <span className="px-3 py-1 bg-white rounded-full text-xs font-semibold text-gray-700">
                {service.status}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Alerts */}
      <div className="mb-8">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Alertas Importantes</h2>
        {alerts.map((alert) => {
          const Icon = alert.icon
          return (
            <div key={alert.id} className="card border-l-4 border-orange-300 bg-orange-50">
              <div className="flex items-start gap-3">
                <Icon className={`${alert.color} mt-1 flex-shrink-0`} size={20} />
                <div>
                  <p className="font-semibold text-gray-800">{alert.type}</p>
                  <p className="text-sm text-gray-600 mt-1">{alert.message}</p>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* CTA Button */}
      <div className="mb-8">
        <button className="btn-primary w-full">
          + Solicitar Novo Serviço
        </button>
      </div>

      {/* How It Works Section */}
      <HowItWorks
        title="Como Funciona o Dashboard"
        description="Entenda como usar a tela inicial do Marina Boat"
        steps={[
          {
            number: 1,
            title: 'Visualize Seus Serviços',
            description: 'Na seção "Próximos Serviços", você vê todos os serviços agendados para suas embarcações. Clique em qualquer um para acompanhar o progresso em tempo real.',
          },
          {
            number: 2,
            title: 'Receba Alertas',
            description: 'A seção "Alertas Importantes" mostra informações críticas, como documentos a vencer ou manutenções programadas. Fique sempre atualizado!',
          },
          {
            number: 3,
            title: 'Solicite Serviços',
            description: 'Use o botão "+ Solicitar Novo Serviço" para abrir o formulário de solicitação. Escolha sua embarcação, o tipo de serviço e envie para a marina.',
          },
          {
            number: 4,
            title: 'Acompanhe em Tempo Real',
            description: 'Após solicitar, você receberá atualizações sobre o status do seu serviço (orçamento, aprovação, em execução, concluído).',
          },
        ]}
      />
    </div>
  )
}

export default Home

