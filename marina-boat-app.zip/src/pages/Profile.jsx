import { useState } from 'react'
import { User, Mail, Phone, MapPin, LogOut, Settings, CreditCard, Heart, Share2 } from 'lucide-react'
import HowItWorks from '../components/HowItWorks'

function Profile({ user, onLogout }) {
  const [showSettings, setShowSettings] = useState(false)

  const profileMenuItems = [
    {
      icon: CreditCard,
      label: 'Pagamentos',
      description: 'Gerencie suas formas de pagamento',
      color: 'text-blue-500',
    },
    {
      icon: Heart,
      label: 'Programa de Indicação',
      description: 'Indique amigos e ganhe benefícios',
      color: 'text-red-500',
    },
    {
      icon: Share2,
      label: 'Meu Próximo Barco',
      description: 'Venda seu barco ou faça upgrade',
      color: 'text-green-500',
    },
    {
      icon: Settings,
      label: 'Configurações',
      description: 'Preferências e segurança',
      color: 'text-gray-500',
    },
  ]

  return (
    <div className="max-w-2xl mx-auto p-4 pt-6 pb-24">
      {/* Profile Header */}
      <div className="bg-gradient-to-br from-marina-blue to-marina-dark rounded-2xl p-6 text-white mb-8">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center">
            <User size={32} className="text-marina-blue" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{user?.name || 'Usuário'}</h1>
            <p className="text-marina-light">{user?.email || 'usuario@email.com'}</p>
          </div>
        </div>
      </div>

      {/* Profile Info */}
      <div className="card mb-8">
        <h2 className="text-lg font-bold text-gray-800 mb-4">Informações Pessoais</h2>
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <Mail size={20} className="text-marina-blue" />
            <div>
              <p className="text-xs text-gray-600">Email</p>
              <p className="font-semibold text-gray-800">{user?.email || 'usuario@email.com'}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Phone size={20} className="text-marina-blue" />
            <div>
              <p className="text-xs text-gray-600">Telefone</p>
              <p className="font-semibold text-gray-800">(11) 97391-7385</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <MapPin size={20} className="text-marina-blue" />
            <div>
              <p className="text-xs text-gray-600">Localização</p>
              <p className="font-semibold text-gray-800">São Paulo, SP - Represa Guarapiranga</p>
            </div>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="space-y-3 mb-8">
        {profileMenuItems.map((item, idx) => {
          const Icon = item.icon
          return (
            <button
              key={idx}
              className="card w-full text-left hover:shadow-lg transition-shadow"
              onClick={() => {
                if (item.label === 'Configurações') setShowSettings(!showSettings)
              }}
            >
              <div className="flex items-start gap-3">
                <Icon size={24} className={item.color} />
                <div className="flex-1">
                  <h3 className="font-bold text-gray-800">{item.label}</h3>
                  <p className="text-sm text-gray-600">{item.description}</p>
                </div>
              </div>
            </button>
          )
        })}
      </div>

      {/* Settings Section */}
      {showSettings && (
        <div className="card mb-8 border-2 border-marina-blue">
          <h3 className="font-bold text-gray-800 mb-4">Configurações</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Notificações Push</span>
              <input type="checkbox" defaultChecked className="w-5 h-5" />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Notificações por Email</span>
              <input type="checkbox" defaultChecked className="w-5 h-5" />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Modo Escuro</span>
              <input type="checkbox" className="w-5 h-5" />
            </div>
          </div>
        </div>
      )}

      {/* Logout Button */}
      <button
        onClick={onLogout}
        className="w-full bg-red-500 text-white py-3 rounded-lg font-bold hover:bg-red-600 transition-colors flex items-center justify-center gap-2 mb-8"
      >
        <LogOut size={20} />
        Sair
      </button>

      {/* How It Works */}
      <HowItWorks
        title="Gerencie Seu Perfil"
        description="Saiba como usar as funcionalidades do seu perfil"
        steps={[
          {
            number: 1,
            title: 'Visualize Seus Dados',
            description: 'Sua foto de perfil, nome, email e localização aparecem no topo. Clique para editar suas informações.',
          },
          {
            number: 2,
            title: 'Gerencie Pagamentos',
            description: 'Adicione ou remova formas de pagamento (cartão, PIX). Seus dados são protegidos com criptografia.',
          },
          {
            number: 3,
            title: 'Programa de Indicação',
            description: 'Indique amigos para o Marina Boat e ganhe pontos e descontos em serviços. Quanto mais indicações, mais benefícios!',
          },
          {
            number: 4,
            title: 'Venda ou Upgrade de Barco',
            description: 'Solicite uma avaliação para vender seu barco atual ou receba sugestões de barcos para upgrade no inventário da Web Boat.',
          },
        ]}
      />
    </div>
  )
}

export default Profile

