import { useState } from 'react'
import { Ship, Plus, Edit2, Trash2, FileText } from 'lucide-react'
import HowItWorks from '../components/HowItWorks'

function Vessels() {
  const [vessels, setVessels] = useState([
    {
      id: 1,
      name: 'Lancha Azul',
      type: 'Lancha',
      brand: 'Phantom',
      model: 'Phantom 25',
      year: 2020,
      length: '25 pés',
      documents: ['Documentação em dia', 'Seguro válido até 2026'],
    },
    {
      id: 2,
      name: 'Veleiro Branco',
      type: 'Veleiro',
      brand: 'Beneteau',
      model: 'Oceanis 35',
      year: 2018,
      length: '35 pés',
      documents: ['Documentação em dia', 'Seguro válido até 2025'],
    },
  ])

  const [showForm, setShowForm] = useState(false)
  const [selectedVessel, setSelectedVessel] = useState(null)

  return (
    <div className="max-w-2xl mx-auto p-4 pt-6 pb-24">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Minhas Embarcações</h1>
        <p className="text-gray-600">Gerencie suas embarcações e documentos</p>
      </div>

      {/* Vessels List */}
      <div className="space-y-4 mb-8">
        {vessels.map((vessel) => (
          <div key={vessel.id} className="card">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start gap-3">
                <Ship className="text-marina-blue mt-1" size={28} />
                <div>
                  <h3 className="font-bold text-lg text-gray-800">{vessel.name}</h3>
                  <p className="text-sm text-gray-600">
                    {vessel.brand} {vessel.model} ({vessel.year})
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                  <Edit2 size={18} className="text-blue-500" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                  <Trash2 size={18} className="text-red-500" />
                </button>
              </div>
            </div>

            <div className="text-sm text-gray-600 mb-3">
              <p>Comprimento: {vessel.length}</p>
            </div>

            {/* Documents */}
            <div className="bg-marina-light rounded-lg p-3 mb-3">
              <div className="flex items-center gap-2 mb-2">
                <FileText size={16} className="text-marina-blue" />
                <span className="font-semibold text-sm text-gray-800">Documentos</span>
              </div>
              <ul className="text-xs text-gray-700 space-y-1">
                {vessel.documents.map((doc, idx) => (
                  <li key={idx}>✓ {doc}</li>
                ))}
              </ul>
            </div>

            <button className="w-full py-2 border border-marina-blue text-marina-blue rounded-lg font-semibold hover:bg-marina-light transition-colors text-sm">
              Ver Detalhes
            </button>
          </div>
        ))}
      </div>

      {/* Add New Vessel Button */}
      <button
        onClick={() => setShowForm(true)}
        className="btn-primary w-full flex items-center justify-center gap-2 mb-8"
      >
        <Plus size={20} />
        Adicionar Embarcação
      </button>

      {/* Add Vessel Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end z-50">
          <div className="bg-white w-full rounded-t-3xl p-6 max-h-96 overflow-y-auto">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Adicionar Embarcação</h2>

            <form className="space-y-4">
              <div>
                <label className="block text-gray-700 font-semibold mb-2">Nome da Embarcação</label>
                <input type="text" placeholder="Ex: Lancha Azul" className="input-field" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Marca</label>
                  <input type="text" placeholder="Ex: Phantom" className="input-field" />
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Modelo</label>
                  <input type="text" placeholder="Ex: Phantom 25" className="input-field" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Ano</label>
                  <input type="number" placeholder="2020" className="input-field" />
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Comprimento</label>
                  <input type="text" placeholder="25 pés" className="input-field" />
                </div>
              </div>

              <div>
                <label className="block text-gray-700 font-semibold mb-2">Tipo</label>
                <select className="input-field">
                  <option>Lancha</option>
                  <option>Veleiro</option>
                  <option>Iate</option>
                  <option>Catamarã</option>
                </select>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="btn-secondary flex-1"
                >
                  Cancelar
                </button>
                <button type="submit" className="btn-primary flex-1">
                  Adicionar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* How It Works */}
      <HowItWorks
        title="Como Gerenciar Suas Embarcações"
        description="Saiba como cadastrar e manter suas embarcações atualizadas"
        steps={[
          {
            number: 1,
            title: 'Cadastre Sua Embarcação',
            description: 'Clique em "+ Adicionar Embarcação" e preencha os dados básicos: nome, marca, modelo, ano e tipo.',
          },
          {
            number: 2,
            title: 'Mantenha Documentos Atualizados',
            description: 'Após cadastrar, você pode adicionar documentos importantes (seguro, documentação, etc.) na seção de detalhes.',
          },
          {
            number: 3,
            title: 'Receba Alertas de Vencimento',
            description: 'O App alertará automaticamente quando documentos como seguro ou inspeção estiverem próximos de vencer.',
          },
          {
            number: 4,
            title: 'Solicite Serviços Específicos',
            description: 'Com a embarcação cadastrada, você pode solicitar serviços específicos para ela na seção "Serviços".',
          },
        ]}
      />
    </div>
  )
}

export default Vessels

