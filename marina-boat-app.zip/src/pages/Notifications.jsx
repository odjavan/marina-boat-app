import { Bell, Trash2, CheckCircle, AlertCircle, Info } from 'lucide-react'
import HowItWorks from '../components/HowItWorks'

function Notifications() {
  const notifications = [
    {
      id: 1,
      type: 'success',
      title: 'Serviço Concluído',
      message: 'A limpeza da Lancha Azul foi concluída com sucesso!',
      timestamp: '2 horas atrás',
      icon: CheckCircle,
    },
    {
      id: 2,
      type: 'alert',
      title: 'Documento Vencendo',
      message: 'O seguro do Veleiro Branco vence em 15 dias. Renove agora!',
      timestamp: '5 horas atrás',
      icon: AlertCircle,
    },
    {
      id: 3,
      type: 'info',
      title: 'Orçamento Disponível',
      message: 'Orçamento para manutenção de motor está pronto para análise.',
      timestamp: '1 dia atrás',
      icon: Info,
    },
    {
      id: 4,
      type: 'info',
      title: 'Serviço Agendado',
      message: 'Sua solicitação de limpeza foi agendada para 28/10/2025.',
      timestamp: '2 dias atrás',
      icon: Info,
    },
  ]

  const getColorClasses = (type) => {
    const colors = {
      success: 'bg-green-50 border-green-300 text-green-700',
      alert: 'bg-red-50 border-red-300 text-red-700',
      info: 'bg-blue-50 border-blue-300 text-blue-700',
    }
    return colors[type] || colors.info
  }

  return (
    <div className="max-w-2xl mx-auto p-4 pt-6 pb-24">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Notificações</h1>
        <p className="text-gray-600">Acompanhe todas as atualizações</p>
      </div>

      {/* Notifications List */}
      <div className="space-y-3 mb-8">
        {notifications.map((notif) => {
          const Icon = notif.icon
          return (
            <div
              key={notif.id}
              className={`card border-l-4 ${getColorClasses(notif.type)} flex items-start justify-between`}
            >
              <div className="flex items-start gap-3 flex-1">
                <Icon size={20} className="mt-1 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="font-bold text-gray-800">{notif.title}</h3>
                  <p className="text-sm text-gray-700 mt-1">{notif.message}</p>
                  <p className="text-xs text-gray-600 mt-2">{notif.timestamp}</p>
                </div>
              </div>
              <button className="p-2 hover:bg-white rounded-lg transition-colors flex-shrink-0">
                <Trash2 size={18} className="text-gray-400 hover:text-red-500" />
              </button>
            </div>
          )
        })}
      </div>

      {/* Empty State Example */}
      <div className="text-center py-12 bg-gray-100 rounded-lg">
        <Bell size={48} className="mx-auto text-gray-400 mb-4" />
        <p className="text-gray-600">Você está em dia com todas as notificações!</p>
      </div>

      {/* How It Works */}
      <div className="mt-8">
        <HowItWorks
          title="Entenda as Notificações"
          description="Saiba o que significa cada tipo de notificação"
          steps={[
            {
              number: 1,
              title: 'Notificações de Sucesso (Verde)',
              description: 'Indicam que uma ação foi concluída com sucesso, como um serviço finalizado ou documento enviado.',
            },
            {
              number: 2,
              title: 'Alertas Importantes (Vermelho)',
              description: 'Indicam situações que requerem sua atenção, como documentos vencendo ou problemas identificados.',
            },
            {
              number: 3,
              title: 'Informações Gerais (Azul)',
              description: 'Informações sobre atualizações, agendamentos ou novidades que não requerem ação imediata.',
            },
            {
              number: 4,
              title: 'Gerencie Suas Notificações',
              description: 'Você pode deletar notificações clicando no ícone de lixo. Elas também podem ser silenciadas nas configurações.',
            },
          ]}
        />
      </div>
    </div>
  )
}

export default Notifications

