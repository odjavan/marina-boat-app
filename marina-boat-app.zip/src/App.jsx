import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Navigation from './components/Navigation'
import Home from './pages/Home'
import Services from './pages/Services'
import Vessels from './pages/Vessels'
import Notifications from './pages/Notifications'
import Profile from './pages/Profile'
import Login from './pages/Login'

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [currentUser, setCurrentUser] = useState(null)

  const handleLogin = (userData) => {
    setIsLoggedIn(true)
    setCurrentUser(userData)
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setCurrentUser(null)
  }

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />
  }

  return (
    <Router>
      <div className="app-container flex flex-col h-screen bg-gray-50">
        <main className="flex-1 overflow-y-auto pb-20">
          <Routes>
            <Route path="/" element={<Home user={currentUser} />} />
            <Route path="/services" element={<Services />} />
            <Route path="/vessels" element={<Vessels />} />
            <Route path="/notifications" element={<Notifications />} />
            <Route path="/profile" element={<Profile user={currentUser} onLogout={handleLogout} />} />
          </Routes>
        </main>
        <Navigation />
      </div>
    </Router>
  )
}

export default App

